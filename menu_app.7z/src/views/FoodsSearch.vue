<template>
  <div class="foods-container">
    <Back />
    <div class="foods-wrapper">
      <div class="foods-menu" @click="goMenu">查看更多种类</div>
<!--      <div class="foods-title"></div>-->
      <div class="foods-list" ref="listContain">
        <ul class="food-list-contain">
          <li class="food-list-item" v-for="(i,index) in foodsSearch" :key="index" @click="getMake(index)">
            <div class="food-icon">
              <img :src="i.pic" class="auto-img" />
            </div>
            <div class="food-content">
              <h3 class="food-name">{{i.name}}</h3>
              <p class="food-tag">{{i.tag}}</p>
              <p class="food-people">{{i.peoplenum}}</p>
              <p class="food-time">{{i.preparetime}}</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import Back from '../components/Back'
  export default {
    data() {
      return {
        foodsSearch: []
      }
    },
    mounted() {
      let str = `/api/recipe/search?keyword=${this.$route.params.txt}&num=10&appkey=2676f1524105c839`
      this.axios(str).then(res => {
//      console.log('res', res)
        this.foodsSearch = res.data.result.list
        console.log(this.foodsSearch)
//      console.log(this.$route.params.id)
      });
//    console.log(this.$route.params.txt)
    },
    components: {
      Back
    }
  }
</script>

<style lang="scss" scoped>
  .foods-container {
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    background-color: #fff;
    
   
    
  }
</style>