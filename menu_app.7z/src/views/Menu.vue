<template>
  <div class="container">
    <div class="menu-title">
      <ul class="menu-title-list">
        <li class="menu-item" v-for="(i,index) in menu" :key="i.classid" @click="getContain(i.list,index)" :class="{active:index == ind}">
          {{i.name}}
        </li>
        <li class="back" @click="$router.push('/')"><i class="back-btn icon-arrow_lift"></i><span class="back-text">返回</span></li>
      </ul>
    </div>
    <div class="menu-contain" ref="menuContain">
      <div class="menu-contain-list">
        <span class="menu-contain-item" v-for="(i,index) in lists" :key="index" @click="getMenu(i.classid)" >{{i.name}}</span>
      </div>
    </div>
    <router-view/>
  </div>
</template>

<script>
  import BScroll from "better-scroll";
  export default {
    props: {
//    menu: {
//      type: Array,
//      required: true
//    },

    },
    data() {
      return {
        menu: "",
        lists: [],
        ind: 0,
        foods: []
      }
    },
    methods: {
      getContain(i,index) {
        this.lists = i
        this.ind = index
      },
      getMenu(id) {
//      console.log(id)
        let str = `/api/recipe/byclass?classid=${id}&start=0&num=10&appkey=2676f1524105c839`
      this.axios(str).then(res => {
//      console.log('res', res)
        this.foods = res.data.result.list

//      :to="{name:'Foods',params:{menu:menu,name:i.name}}"
//      console.log(this.$route.params.id)
//      console.log(this.menu)
//  
    this.$router.push({ name: 'Foods', params: { foods: this.foods }})
//  console.log(res.data.result,12)
//  console.log(this.foods,12)
      });
      console.log(id)
       
      },
      initalScroll() {
        if(!this.menuScroller) {
          // 避免内存泄漏，当menuScroller已经被创建时无需再实例化新的BScroll对象
          this.menuScroller = new BScroll(this.$refs.menuContain, {
            click: true
          });
        } else {
          this.menuScroller.refresh();
        }

        //      if(!this.goodsScroller) {
        //        // 避免内存泄漏，当goodsScroller已经被创建时无需再实例化新的BScroll对象
        //        this.goodsScroller = new BScroll(this.$refs.goodsWrapper, {
        //          click: true,
        //          probeType: 2
        //        });
        //        this.goodsScroller.on("scroll", this.refreshMenuScrollCurrentIndex);
        //      } else {
        //        this.goodsScroller.refresh();
        //      }
      },
      destroyScroll() {
        if(this.menuScroller) {
          this.menuScroller.destroy();
          this.menuScroller = null;
        }

      },
    },
    mounted() {
      this.axios("/api/recipe/class?appkey=88aaa8c401d177dc").then(res => {
//      console.log('res', res.data.result)
        this.menu = res.data.result
        console.log(this.menu)
        if(this.lists == "") {
                      this.lists = this.menu[0].list;
        
            }
      });
      this.$nextTick(() => {
        this.initalScroll();
      });
            
    },
    beforeDestroy() {
      this.destroyScroll();

    }
  }
</script>

<style lang="scss" scoped>
  .container {
    width: 100vw;
    height: 100vh;
    position: fixed;
    left: 0;
    top: 0;
    font-size: 14px;
    .menu-title {
      position: absolute;
      left: 0;
      top: 0;
      width: 80px;
      height: 100vh;
      font-size: 18px;
      .menu-title-list {
        width: 100%;
        height: 100%;
        background-color: #eee;
      }
      .back {
        position: fixed;
        left: 0;
        bottom: 0;
        width: 80px;
        line-height: 40px;
        height: 40px;
        text-align: center;
      }
      
      .back-btn {
        display: inline-block;
        line-height: 40px;
        height: 40px;
        vertical-align: top;
      }
      .back-text {
        display: inline-block;
        line-height: 40px;
        height: 40px;
        vertical-align: top;
      }
      
      .menu-item {
        line-height: 40px;
        height: 40px;
        text-align: center;
        
        &.active {
          background-color: #FA6650;
          color: #fff;
        }
        
      }
    }
    .menu-contain {
      position: absolute;
      height: 100vh;
      left: 80px;
      top: 0;
      .menu-contain-list {
        width: 100%;
        overflow: hidden;
      }
      .menu-contain-item {
        width: 80px;
        padding: 20px 0;
        display: inline-block;
        text-align: center;
        color: rgba(51, 47, 47, 0.829);
      }
    }
  }
</style>