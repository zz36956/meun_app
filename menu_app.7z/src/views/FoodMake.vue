<template>
  <div class="food-make-container">
    <div class="top" @click="goHome">
      <span class="mou text">某</span>
      <span class="mei text">美</span>
      <span class="shi text">食</span>
      
    </div>
    <div class="food-make-wrapper">
      <div class="foods-menu" @click="goMenu">查看更多种类</div>
      <div class="food-icon">
        <img :src="foodMake.pic" class="auto-img" />
      </div>
      <div class="food-name">
        {{foodMake.name}}
      </div>
      <div class="food-content">
        {{foodMake.content}}
      </div>
      <WhiteSpace />
      <div class="food-mes">
          <h2 class="title">准备时间</h2>
          <p class="text">{{foodMake.preparetime}}</p>
          <h2 class="title">烹饪时间</h2>
          <p class="text">{{foodMake.cookingtime}}</p>
          <h2 class="title">人数</h2>
          <p class="text">{{foodMake.peoplenum}}</p>
          <h2 class="title">美食标签</h2>
          <p class="text">{{foodMake.tag}}</p>
      </div>
      <WhiteSpace />
      <div class="food-step">
        <h3 class="food-step-title">准备材料</h3>
        <ul>
          <li class="food-step-text" :class="{active: i.type==1}" v-for="(i,index) in foodMake.material" :key="index">
            {{i.mname}}:{{i.amount}}
            <span v-show="i.type == 1">（主要食材）</span>
          </li>
        </ul>
      </div>
      <WhiteSpace />
      <div class="food-make">
        <h3 class="food-make-title">开始烹饪</h3>
        <ul class="food-make-list">
          <li v-for="(m,ind) in foodMake.process" :key="ind" class="food-make-item">
            <div class="title">步骤{{ind+1}}</div>
            <div class="icon">
              <img :src="m.pic" class="auto-img" />
            </div>
            <div class="text">
              {{m.pcontent}}
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
//import Back from '../components/Back'
import WhiteSpace from "../components/WhiteSpace";
  
  export default {
    props: {
      foodMake: {
        type: Object,
        required: true
      },
    data() {
      return {
        foods: []
      }
    }
    },
    methods: {
       goHome() {
        this.$router.replace('/')
      },
      goMenu() {
        this.$router.replace('/menu')
      },
    },
    mounted() {
      console.log(this.foodMake)
    },
      components: {
    WhiteSpace,
  },
  }
</script>

<style lang="scss" scoped>
    .food-make-container {
      position: relative;
      left: 0;
      top: 0;
      width: 100vw;
      height: 100vh;
      
      .top {
/*      display: inline-block;*/
      position: fixed;
      padding-left: 15px;
      width: 100%;
      height: 40px;
      font-size: 22px;
      line-height: 40px;
      color: #fff;
      z-index: 99;
      background-color: #fff;
/*      background-color: #FA6650;*/
      
      .text {
        display: inline-block;
        margin-left: 5px;
      }
      
      .mou {
        color: #86CEDC;
      }
      
      .mei {
        color: darkred;
      }
      
      .shi {
        color: pink;
      }
      
    }
    
    .food-make-wrapper {
      position: absolute;
      top: 50px;
/*      padding: 0 16px;*/
      
      .foods-menu {
        padding: 0 20px;
        margin: 2px auto;
        box-sizing: border-box;
        background-color: #FA6650;
        width: 90%;
        height: 50px;
        text-align: center;
        line-height: 42px;
        font-size: 18px;
        color: #fff;
      }
      
      .food-icon {
        padding: 10px 16px;
        width: 100%;
        height: 300px;
        
        
        
      }
      
      .food-name {
        padding: 0 16px;
        margin-top: 10px;
        font-size: 30px;
        font-weight: bolder;
        line-height: 40px;
        text-align: center;
      }
      
      .food-content {
        padding: 10px 16px;
 /*        margin-top: 4px;*/
        font-size: 12px;
        color: rgb(147, 153, 159);
        line-height: 15px;
        overflow: hidden;
        text-overflow:ellipsis;
      }
      
      .food-mes {
/*        margin-top: 4px;*/
        padding: 10px 16px;
        .title {
        color: rgb(240, 20, 20);
        font-size: 14px;
          font-weight: 700;
          line-height: 24px;
          margin-top: 4px;
        }
        
        .text {
/*          margin-top: 4px;*/
          margin-bottom: 8px;
           font-size: 16px;
          font-weight: normal;
        color: rgb(147, 153, 159);
        }
        
      }
      
      .food-step {
/*        margin-top: 4px;*/
        padding: 10px 16px;
        .food-step-title {
          color: rgb(240, 20, 20);
        font-size: 14px;
          font-weight: 700;
          line-height: 24px;
        }
        
        .food-step-text {
          margin-top: 4px;
          margin-bottom: 8px;
           font-size: 16px;
          font-weight: normal;
        color: rgb(147, 153, 159);
        
        &.active {
          color: red;
        }
        
        }
        
      }
      
      .food-make {
/*        margin-top: 4px;*/
        padding: 10px 16px;
        
        .food-make-title {
          color: rgb(240, 20, 20);
        font-size: 18px;
          font-weight: 700;
          line-height: 24px;
        }
        
        .food-make-item {
/*          margin-top: 8px;*/
            padding: 10px 0px;
          
          .title {
            color: #F96650;
        font-size: 18px;
          font-weight: 700;
          line-height: 24px;
/*          margin-top: 4px;*/
          }
          
          .icon {
            margin-top: 6px;
            margin-bottom: 6px;
          }
          
          .text {
            margin-top: 4px;
           font-size: 20px;
          font-weight: normal;
        color: #383831;
          }
          
        }
        
      }
      
      
    }
      
    }
</style>