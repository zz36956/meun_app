<template>
  <div class="home">
    <!--<img alt="Vue logo" src="../assets/logo.png">
    <HelloWorld msg="Welcome to Your Vue.js App"/>-->
    <div class="home-top">
      <div class="home-top-text">
        <span class="mou text">某</span>
        <span class="mei text">美</span>
        <span class="shi text">食</span>
      </div>
      <input v-model="search" class="home-top-inp" placeholder="搜索美食关键字" />
      <button @click="serchFoods" class="home-top-btn">搜索</button>
    </div>
<!--    <WhiteSpace />-->
    <div class="food-wheel-title">
      <p>今日推荐美食</p>
    </div>
    <div class="food-wheel">
      <transition-group name="roll">
        <div class="food-wheel-item" v-for="(i,ind) in wheelFoods" :key="i.id" v-show="ind === index" @click="goWheelFood(ind)">
          <div class="food-wheel-item-icon">
            <img :src="i.pic" class="auto-img" />
          </div>
          <div class="food-wheel-item-text">
            <div class="food-wheel-item-text-name">
              {{i.name}}
            </div>
            <div class="food-wheel-item-text-tag">
              {{i.tag}}
            </div>
          </div>
        </div>
      </transition-group>
    </div>
    <WhiteSpace />
          <div class="hot-class-title">热门分类</div>
    <div class="hot-class">
      <div v-for="(i,index) in hotClass" :key="i.classid" class="hot-class-item" @click="getMenu(i.classid)">
        <img :src="img[index]" class="auto-img hot-class-item-icon" />
        <div class="hot-class-item-mark"></div>
        <div class="hot-class-item-name">{{i.name}}</div>
      </div>
    </div>
    <WhiteSpace />
    <router-link class="foods-menu" tag="div" to="/menu" exact>查看所有美食分类</router-link>
    <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
  // @ is an alias to /src
  //import HelloWorld from '@/components/HelloWorld.vue'
  import WhiteSpace from "../components/WhiteSpace";

  export default {

    name: 'Home',
    data() {
      return {
        search: "",
        foods: [],
        wheelFoodsId: [15, 855, 38, 21],
        wheelFoods: [],
        hotClassId: [2, 5, 588, 594, 573, 281],
        hotClass: [],
        index: 0,
        //      img1: require("../assets/img/pic_01.jpg"),
        //      img2: require("../assets/img/pic_02.jpg"),
        //      img3: require("../assets/img/pic_03.jpg"),
        //      img4: require("../assets/img/pic_04.jpg"),
        //      img5: require("../assets/img/pic_05.jpg"),
        //      img6: require("../assets/img/pic_06.jpg"),
        img: [
          require("../assets/img/pic_01.jpg"),
          require("../assets/img/pic_02.jpg"),
          require("../assets/img/pic_03.jpg"),
          require("../assets/img/pic_04.jpg"),
          require("../assets/img/pic_05.jpg"),
          require("../assets/img/pic_06.jpg"),
        ]
      }
    },
    methods: {
      serchFoods() {
        if(this.search) {

          let str = `/api/recipe/search?keyword=${this.search}&num=10&appkey=2676f1524105c839`
          this.axios(str).then(res => {
            //      console.log('res', res)
            this.foods = res.data.result.list
            console.log(this.foods)
            //      console.log(this.$route.params.id)
            this.$router.push({
              name: 'Foods',
              params: {
                foods: this.foods
              }
            })
          });

          this.search = ""
        }

        //this.$router.push({
        //name: 'Foods',
        //params: {
        //  txt: this.search
        //
        //}
        //})

      },
      goWheelFood(ind) {
        this.$router.push({
          name: 'FoodMake',
          params: {
            foodMake: this.wheelFoods[ind]
          }
        })
      },
      getMenu(id) {
//      console.log(id)
        let str = `/api/recipe/byclass?classid=${id}&start=0&num=10&appkey=2676f1524105c839`
      this.axios(str).then(res => {
//      console.log('res', res)
        this.foods = res.data.result.list

//      :to="{name:'Foods',params:{menu:menu,name:i.name}}"
//      console.log(this.$route.params.id)
//      console.log(this.menu)
//  
    this.$router.push({ name: 'Foods', params: { foods: this.foods }})
//  console.log(res.data.result,12)
//  console.log(this.foods,12)
      });
      console.log(id)
       
      },
    },
    mounted() {
      this.wheelFoodsId.forEach(i => {
        let str = `/api/recipe/detail?id=${i}&appkey=2676f1524105c839`;
        this.axios(str).then(res => {
          //      console.log('res', res)
          this.wheelFoods.push(res.data.result)
          //        console.log(res)
          //      console.log(this.$route.params.id)
          //        this.$router.push({
          //          name: 'Foods',
          //          params: {
          //            foods: this.foods
          //          }
          //        })
        });
      })
      this.timer = setInterval(() => {
        if(this.index < this.wheelFoods.length - 1) {
          this.index++
        } else {
          this.index = 0
        }

      }, 2000);
      this.axios("/api/recipe/class?appkey=88aaa8c401d177dc").then(res => {
        //      console.log('res', res.data.result)
        res.data.result.forEach(i => {
          i.list.forEach(m => {
            this.hotClassId.forEach(k => {
              if(k == m.classid) {
                this.hotClass.push(m)

              }
            })
          })
        })
        console.log(this.hotClass)

      });
      //    console.log(this.wheelFoods)
    },
    components: {
      WhiteSpace,
    },
  }
</script>

<style lang="scss" scoped>
  .home-top {
    padding: 5px 10px;
    display: flex;
    width: 100vw;
    height: 40px;
    background-color: #FA6650;
    box-sizing: border-box;
    .home-top-text {
      display: inline-block;
      flex: 0 0 80px;
      height: 30px;
      font-size: 22px;
      line-height: 30px;
      color: #fff;
      .text {
        display: inline-block;
        margin-left: 3px;
      }
      .mou {
        color: #86CEDC;
      }
      .mei {
        color: darkred;
      }
      .shi {
        color: pink;
      }
    }
    .home-top-inp {
      padding: 2px 10px;
      margin: 4px 2px;
      flex: auto;
      height: 20px;
      /*        vertical-align: top;*/
      border: none;
      outline: none;
      border-radius: 10px;
    }
    .home-top-btn {
      flex: 0 0 50px;
      background-color: transparent;
      color: #fff;
      border: none;
      outline: none;
    }
  }
  
  .food-wheel-title {
    padding: 0 20px;
    margin: 0px auto;
    margin-top: 0;
    box-sizing: border-box;
    background-color: #fff;
    width: 100%;
    height: 30px;
    text-align: center;
    line-height: 32px;
    font-size: 18px;
    color: #000;
  }
  
  .food-wheel {
    margin: 0px auto;
    position: relative;
    width: 100vw;
    height: 234px;
    overflow: hidden;
    .food-wheel-item {
      position: absolute;
      &.roll-enter {
        transform: translatex(100%);
      }
      &.roll-enter-active,
      &.roll-leave-active {
        transition: all 1s linear;
      }
      &.roll-enter-to,
      &.roll-leave {
        transform: translatex(0);
      }
      &.roll-leave-to {
        transform: translatex(-100%);
      }
      .food-wheel-item-icon {
        width: 70vw;
        height: 150px;
        text-align: center;
        margin: 2px auto;
      }
      .food-wheel-item-text {
        padding: 4px 16px;
        width: 100%;
        height: 100px;
        .food-wheel-item-text-name {
          color: rgb(240, 20, 20);
          font-size: 18px;
          font-weight: 700;
          line-height: 24px;
          margin-top: 4px;
          text-align: center;
        }
        .food-wheel-item-text-tag {
          margin-top: 4px;
          font-size: 16px;
          font-weight: normal;
          color: rgb(147, 153, 159);
          text-align: center;
        }
      }
    }
  }
  
  .hot-class-title {
    padding: 0 20px;
    margin: 0px auto;
    box-sizing: border-box;
    background-color: #FA6650;
    width: 100%;
    height: 30px;
    text-align: center;
    line-height: 32px;
    font-size: 18px;
    color: #fff;
  }
  
  .hot-class {
    padding: 6px 16px;
    width: 100vw;
    height: 236px;
    display: flex;
    flex-wrap: wrap;
    align-content: flex-start;
    
    .hot-class-item {
      position: relative;
      padding: 6px;
      width: 30vw;
      height: 30vw;
      
      
      .hot-class-item-icon {
        width: 100%;
        height: 100%;
      }
      
      .hot-class-item-mark {
        position: absolute;
        padding: 6px;
        border: 6px solid #fff;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
       /* opacity: 0.4;*/
        background-image: linear-gradient(to top, rgba(0,0,0,1), rgba(0,0,0,0));
      }
      
      .hot-class-item-name {
        position: absolute;
        width: 60px;
        left: 50%;
        margin-left: -30px;
        bottom: 6px;
        color: #fff;
        text-align: center;
        font-size: 14px;
        font-weight: 700;
        line-height: 24px;
      }
      
    }
    
  }
  
  .foods-menu {
    padding: 0 20px;
    margin: 6px auto;
    box-sizing: border-box;
    background-color: #FA6650;
    width: 90%;
    height: 50px;
    text-align: center;
    line-height: 42px;
    font-size: 18px;
    color: #fff;
  }
</style>