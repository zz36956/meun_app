<template>
  <div class="foods-container">
    <Back />
    <div class="foods-wrapper">
<!--      <div class="foods-title"></div>-->
      <div class="foods-list" ref="listContain">
        <ul class="food-list-contain">
          <li class="food-list-item" v-for="(i,index) in foods" :key="index" @click="getMake(index)">
            <div class="food-icon">
              <img :src="i.pic" class="auto-img" />
            </div>
            <div class="food-content">
              <h3 class="food-name">{{i.name}}</h3>
              <p class="food-tag">{{i.tag}}</p>
              <p class="food-people">{{i.peoplenum}}</p>
              <p class="food-time">{{i.preparetime}}</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import Back from '../components/Back'
  import BScroll from "better-scroll";
  export default {
    props: {
      foods: {
        type: Array,
        required: true
      },

    },
//  data() {
//    return {
//      foods: []
//    }
//  },
    methods: {
      goMenu() {
        this.$router.replace('/menu')
      },
      getMake(index) {
        this.$router.push({ name: 'FoodMake', params: { foodMake: this.$route.params.foods[index] }})
      },
      initalScroll() {
        if(!this.listScroller) {
          // 避免内存泄漏，当menuScroller已经被创建时无需再实例化新的BScroll对象
          this.listScroller = new BScroll(this.$refs.listContain, {
            click: true
          });
        } else {
          this.listScroller.refresh();
        }

        //      if(!this.goodsScroller) {
        //        // 避免内存泄漏，当goodsScroller已经被创建时无需再实例化新的BScroll对象
        //        this.goodsScroller = new BScroll(this.$refs.goodsWrapper, {
        //          click: true,
        //          probeType: 2
        //        });
        //        this.goodsScroller.on("scroll", this.refreshMenuScrollCurrentIndex);
        //      } else {
        //        this.goodsScroller.refresh();
        //      }
      },
      destroyScroll() {
        if(this.listScroller) {
          this.listScroller.destroy();
          this.listScroller = null;
        }

      },
    },
    mounted() {
//    let str = `/api/recipe/byclass?classid=${this.$route.params.id}&start=0&num=10&appkey=88aaa8c401d177dc`
//    this.axios(str).then(res => {
////      console.log('res', res)
//      this.foods = res.data.result.list
//      console.log(this.foods)
////      console.log(this.$route.params.id)
////      console.log(this.menu)
//    });
//    this.foods = this.$route.params.foods
//    console.log(this.foods,12)
//    this.goods = this.$route.params.foods;
      this.$nextTick(() => {
        this.initalScroll();
      });
    },
    beforeDestroy() {
      this.destroyScroll();

    },
    components: {
      Back
    }
  }
</script>

<style lang="scss" scoped>
  .foods-container {
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 100vh;
    background-color: #fff;
    
    .foods-wrapper {
      position: relative;
      left: 0;
      top: 60px;
      
      /*.foods-menu {
        padding: 4px;
        margin: 2px auto;
        box-sizing: border-box;
        background-color: #FA6650;
        width: 80%;
        height: 50px;
        text-align: center;
        line-height: 42px;
        font-size: 18px;
        color: #fff;
      }*/
      
      .foods-list {
        padding: 4px;
        margin: 4px auto;
        box-sizing: border-box;
        width: 90%;
        height: 570px;
        overflow: hidden;
      }
      
      .food-list-item {
        display: flex;
        margin-top: 6px;
      }
      
      .food-icon {
        flex: 0 0 80px;
      }
      
      .food-content {
        flex: auto;
        position: relative;
        padding: 6px;
      }
      
      .food-name {
        font-size: 18px;
        font-weight: bolder;
        line-height: 18px;
        color: rgb(7, 17, 27);
      }
      
      .food-tag {
        margin-top: 4px;
        font-size: 12px;
        color: rgb(147, 153, 159);
        height: 30px;
        line-height: 15px;
        overflow: hidden;
        text-overflow:ellipsis;
      }
      
      .food-people {
        position: absolute;
        left: 6px;
        bottom: 0;
        color: rgb(240, 20, 20);
        font-size: 14px;
          font-weight: 700;
          line-height: 24px;
      }
      
      .food-time {
        position: absolute;
        bottom: 0;
        right: 0;
        font-size: 12px;
          font-weight: normal;
/*        color: rgb(147, 153, 159);*/
      }
      
    }
    
  }
</style>
