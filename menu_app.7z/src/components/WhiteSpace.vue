<template>
  <div class="white-space"></div>
</template>

<style lang="scss" scoped>
.white-space {
  height: 16px;
  border-top: 1px solid rgba(7, 17, 27, 0.1);
  border-bottom: 1px solid rgba(7, 17, 27, 0.1);
  background: #f3f5f7;
}
</style>