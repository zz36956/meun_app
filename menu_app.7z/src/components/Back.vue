<template>
  <div class="back">
    <i class="back-btn icon-arrow_lift" @click="$router.go(-1)"></i>
    <div class="back-text" @click="goHome">
      <span class="mou text">某</span>
      <span class="mei text">美</span>
      <span class="shi text">食</span>
    </div>
  </div>
</template>

<script>
  export default {
    methods: {
      goHome() {
        this.$router.replace('/')
      }
    }
  }
</script>

<style lang="scss" scoped>
  .back {
    position: fixed;
    left: 0;
    top: 0;
    width: 100vw;
    height: 50px;
    background-color: #FA6650;
    z-index: 90;
    
    .back-btn {
      display: inline-block;
      position: absolute;
      z-index: 100;
      color: #fff;
      left: 5px;
      top: 10px;
      width: 30px;
      height: 30px;
      line-height: 30px;
    }
    .back-text {
      display: inline-block;
      position: absolute;
      left: 40px;
      top: 5px;
      /*        width: 40px;*/
      height: 40px;
      font-size: 22px;
      line-height: 40px;
      color: #fff;
      
      .text {
        display: inline-block;
        margin-left: 3px;
      }
      
      .mou {
        color: #86CEDC;
      }
      
      .mei {
        color: darkred;
      }
      
      .shi {
        color: pink;
      }
      
    }
  }
</style>