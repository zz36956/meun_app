import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '../views/Home.vue'
import Menu from '../views/Menu.vue'
import Foods from '../views/Foods.vue'
import FoodsSearch from '../views/FoodsSearch.vue'
import FoodMake from '../views/FoodMake.vue'


Vue.use(VueRouter)

  const routes = [
  {
    path: '/',
    name: 'Home',
    component: Home
  },
  {
    path: '/about',
    name: 'About',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/About.vue')
  },
  {
    path: '/menu',
    name: 'Menu',
    component: Menu
  },
  {
    path: '/foods',
    name: 'Foods',
    component: Foods,
    props: true
  },
  {
    path: '/foodsSearch/:txt',
    name: 'FoodsSearch',
    component: FoodsSearch
  },
  {
    path: '/foodMake',
    name: 'FoodMake',
    component: FoodMake,
    props: true
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
