<template>
  <div id="app">
    <!--<router-link to:"/menu" :menu="menu">菜单</router-link>-->
 <!--    <router-link tag="div" to="/menu" exact>商品</router-link>-->
     <keep-alive>
      <router-view></router-view>
    </keep-alive>
  </div>
</template>

<script>
  export default {
    data() {
      return {
       
      }
    },
    mounted() {
      
    },
  }
</script>

<style lang="scss">
  .auto-img {
  width: 100%;
  height: 100%;
}
</style>