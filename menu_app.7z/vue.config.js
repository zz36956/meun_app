module.exports = {
devServer: {
    proxy: {
      "/api": {
        target: "https://api.jisuapi.com",
        changeOrigin: true,
        pathRewrite: {
          "^/api": ""
        }
      }
    }
}
}